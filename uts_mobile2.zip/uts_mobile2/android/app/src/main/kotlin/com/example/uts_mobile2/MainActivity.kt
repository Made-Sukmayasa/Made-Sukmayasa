package com.example.uts_mobile2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
